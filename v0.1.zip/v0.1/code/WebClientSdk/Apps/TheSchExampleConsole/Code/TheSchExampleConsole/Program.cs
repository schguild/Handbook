﻿/********************************************************************************
 * TechGuilds Sitecore Content Hub Handbook .NET Core Console Application
 * 
 * This application provides samples on how to perform given tasks using the Sitecore Content Hub using the WebClient SDK.
 * 
 * Unless otherwise stated the code in this application is meant to be a sample and may not have all the protection code 
 * necessary for production environments. 
 * 
 * LICENSE: This module and all other parts of the Handbook are owned by TechGuilds and may be used under agreed license only.
 *          
 * APIS SAMPLES INCLUDED (More will be included in future versions):
 * 
 *  - ENTITIES: https://docs.stylelabs.com/content/integrations/sdk-common-documentation/clients/entities-client.html?v=3.2.0
 *          
 * KNOWN ISSUES: 
 *          
 * EXTERNAL LIBRARIES USED:
 * 
 * - This client uses the schguild open source module which can be found at: https://github.com/schguild
 * 
 * USAGE INSTRUCTIONS:
 *
 * 1. Right click on TheSchExampleConsole and click on Debug and replace the Program Arguments with your own parameters.
 * 
 * 
 * 
 *********************************************************************************/

// TEMPLATE:
// SCH_BASE_URL|{INSERT_YOUR_BASE_URL} SCH_CLIENT_ID|{INSERT_YOUR_CLIENT_ID} SCH_CLIENT_SECRET|{INSERT_YOUR_CLIENT_SECRET} SCH_USER_NAME|{INSERT_SCH_USER_NAME} SCH_PASSWORD|INSERT_SCH_PASSWORD 

// TO DO: Set up TechGuilds One: 
// SCH_BASE_URL|{INSERT_YOUR_BASE_URL} SCH_CLIENT_ID|{INSERT_YOUR_CLIENT_ID} SCH_CLIENT_SECRET|{INSERT_YOUR_CLIENT_SECRET} SCH_USER_NAME|{INSERT_SCH_USER_NAME} SCH_PASSWORD|INSERT_SCH_PASSWORD 

// EPAM :
// SCH_BASE_URL|https://salesdemo-epam.stylelabs.io SCH_CLIENT_ID|SchDemoCoreConsole SCH_CLIENT_SECRET|SitecoreGuild SCH_USER_NAME|DemoCoreConsole SCH_PASSWORD|Ysa6311a!!

namespace TheSchExampleConsole
{
    using SchGuild.Foundation.WebClient;
    using Stylelabs.M.Sdk.Contracts.Base;
    using System;
    using System.Collections.Generic;

    class Program
    {
        const string DEFAULT_ROOT_PATH = "DEFAULT_ROOT_PATH";

        const string SCH_BASE_URL = "SCH_BASE_URL";
        const string SCH_CLIENT_ID = "SCH_CLIENT_ID";
        const string SCH_CLIENT_SECRET = "SCH_CLIENT_SECRET";
        const string SCH_USER_NAME = "SCH_USER_NAME";
        const string SCH_PASSWORD = "SCH_PASSWORD";
        const string SCH_TASK_NAME = "SCH_TASK_NAME";

        const string ENABLE_METERED = "ENABLE_METERED";

        static void Main(string[] args)
        {
            Console.WriteLine("Welcome To The TechGuilds Hall!");
            Console.WriteLine("The SCH Example Console provides sample calls to the WebClient SDK for general tasks");

            // These are the defaults if debugging
            var rootFolder = AppDomain.CurrentDomain.BaseDirectory + (AppDomain.CurrentDomain.BaseDirectory.EndsWith("\\") ? string.Empty : "\\");

            var schBaseUrl = string.Empty;
            var schClientId = string.Empty;
            var schClientSecret = string.Empty;
            var schUserName = string.Empty;
            var schPassword = string.Empty;

            // IF DEBUGGING Uncomment the rootFolder line below
            rootFolder = "C:\\_clients\\TechGuilds\\Repo\\schinternal\\Handbook\\";

            var providerSettings = new Dictionary<string, string>
            {
                { DEFAULT_ROOT_PATH, rootFolder },
                { SCH_BASE_URL, schBaseUrl },
                { SCH_CLIENT_ID, schClientId },
                { SCH_CLIENT_SECRET, schClientSecret },
                { SCH_USER_NAME, schUserName },
                { SCH_PASSWORD, schPassword },
                { SCH_TASK_NAME, string.Empty }
            };

            if (args.Length > 1)
            {
                foreach (var arg in args)
                {
                    var argParts = arg.Split('|');
                    if (argParts.Length != 2)
                    {
                        Console.WriteLine("ERROR: arg (" + arg + ") does not contain 2 parts");
                        Console.ReadLine();
                        return;
                    }

                    if (providerSettings.ContainsKey(argParts[0].ToUpperInvariant()))
                    {
                        providerSettings[argParts[0]] = argParts[1];
                    }
                    else
                    {
                        providerSettings.Add(argParts[0], argParts[1]);
                    }
                }
            }

            var context = new WebClientContext(providerSettings[SCH_BASE_URL], providerSettings[SCH_CLIENT_ID], providerSettings[SCH_CLIENT_SECRET], providerSettings[SCH_USER_NAME], providerSettings[SCH_PASSWORD]);


            // TO DO: look for the task and if not found then ask
            var taskName = providerSettings[SCH_TASK_NAME];
            if (string.IsNullOrEmpty(taskName))
            {
                Console.WriteLine("Please Enter The Task To Execute:");
                taskName = Console.ReadLine();
            }

            // if we have a task then we will execute it
            if (string.IsNullOrEmpty(taskName) == false)
            {
                // Execute the task
                var result = ExecuteTask(context, taskName);
                Console.WriteLine("***** BEGIN RESULT *****");
                Console.Write(result);
                Console.WriteLine("***** END RESULT *****");
            }

            Console.WriteLine("Now Leaving the Hall see you next time");
        }

        /// <summary>
        /// Executes a task against the Sitecore Content Hub API
        /// </summary>
        /// <param name="context"></param>
        /// <param name="taskName"></param>
        /// <returns></returns>
        public static string ExecuteTask(WebClientContext context, string taskName)
        {
            var jsonResult = string.Empty;

            var definitionName = string.Empty;
            List<IEntity> entities = null;

            switch (taskName.ToUpperInvariant().Trim())
            {
                case "ENTITY_IDS_GET_ALL_FOR_TEMPLATE":
                    Console.WriteLine("Please enter definition name for the template:");
                    definitionName = Console.ReadLine();
                    if (string.IsNullOrEmpty(definitionName))
                    {
                        Console.WriteLine("ERROR: definitionName is required");
                        return string.Empty;
                    }

                    var ids = context.GetEntityIds(definitionName);
                    return "ENTITIES FOUND";

                case "ENTITY_GET_ALL":

                    entities = context.GetEntities();
                    return entities.Count + "ENTITIES FOUND";

                case "ENTITY_GET_ALL_FOR_TEMPLATE":
                    Console.WriteLine("Please enter definition name for the template:");
                    definitionName = Console.ReadLine();
                    if (string.IsNullOrEmpty(definitionName))
                    {
                        Console.WriteLine("ERROR: definitionName is required");
                        return string.Empty;
                    }

                    entities = context.GetEntities(definitionName);
                    return entities.Count + "ENTITIES FOUND";

                default:
                    return string.Empty;
            }
        }
    }
}
