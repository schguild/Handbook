Scripts
-------

To use scripts you must perform the following tasks:

1. In order for scripts to work in Visual Studio Code you will need the Omnisharp Plug-In. https://marketplace.visualstudio.com/items?itemName=ms-dotnettools.csharp

1. Edit the settings.csx to match your environment so it can connect to Sitecore Content Hub. 
2. Copy the Nuget folder from Handbook\3rdParty\sch so it is under the same folder you found your settings.csx
3. Look in runme.csproj at the netcoreapp version. If you are using a different version then change to match yours.
4. Look in .vscode folder for launch.json and it should look something like this if not copy that file in. You will have to edit the path to the dotnet-script.dll as it will not match yours unless your username is chris too :)

{
    "version": "0.2.0",
    "configurations": [
        {
            "name": ".NET Script Debug",
            "type": "coreclr",
            "request": "launch",
            "program": "dotnet",
            "args": [
                "exec",
                "C:/Users/chris/.dotnet/tools/.store/dotnet-script/0.50.1/dotnet-script/0.50.1/tools/netcoreapp3.0/any/dotnet-script.dll",
                "${file}"
            ],
            "cwd": "${workspaceRoot}",
            "stopAtEntry": true
        }
    ]
}

5. Look in omnisharp.json at the netcoreapp version. If you are using a different version then change to match yours.
6. Open the Scripts folder in Visual Studio Code to test your scripts.
7. Click on RunMe.csx and Click on the Run -> Start Debugging. If this works you will see Welcome in the output window.
8. Once that is working you can uncomment other scripts to run in the RunMe.csx




