﻿namespace SchGuild.Foundation.PIM
{
    using SchGuild.Foundation.WebClient;
    using Stylelabs.M.Base.Querying;
    using Stylelabs.M.Sdk.Contracts.Base;
    using System.Collections.Generic;
    using System.Linq;

    /// <summary>
    /// This object can be assigned the credentials and then be used to make all your PIM related API Calls
    /// </summary>
    public class PIMWebClientContext : WebClientContext
    {

        /// <summary>
        /// 
        /// </summary>
        public const string PRODUCT_FAMILY_TEMPLATE = "M.PIM.ProductFamily";

        /// <summary>
        /// 
        /// </summary>
        public const string PRODUCT_TEMPLATE = "M.PIM.Product";


        /// <summary>
        /// 
        /// </summary>
        /// <param name="baseUrl">The part of the url with server name up until the first slash</param>
        /// <param name="clientId"></param>
        /// <param name="clientSecret"></param>
        /// <param name="userName"></param>
        /// <param name="password"></param>
        public PIMWebClientContext(string baseUrl, string clientId, string clientSecret, string userName, string password)
        {
            BaseUrl = baseUrl;
            ClientId = clientId;
            ClientSecret = clientSecret;
            UserName = userName;
            Password = password;
        }

        /// <summary>
        /// Gets All the product families
        /// </summary>
        /// <returns></returns>
        public List<IEntity> GetProductFamilies()
        {
            // IMPORTANT: If you don't authenticate on each call then you have to use the event to know when token expires.
            // It is easier to simply do it on each call.
            var webMClient = AuthenticateMClient();

            //  This is the API to get all assets /api/entities/query?query=Definition.Name=='M.Asset'

            var query = Query.CreateQuery(entities =>
                from e in entities
                where e.DefinitionName == PRODUCT_FAMILY_TEMPLATE
                orderby e.CreatedOn ascending
                select e);

            return webMClient.Querying.QueryAsync(query).Result.Items.ToList();
        }


        /// <summary>
        /// Gets All the products
        /// </summary>
        /// <returns></returns>
        public List<IEntity> GetProducts()
        {
            // IMPORTANT: If you don't authenticate on each call then you have to use the event to know when token expires.
            // It is easier to simply do it on each call.
            var webMClient = AuthenticateMClient();

            //  This is the API to get all assets /api/entities/query?query=Definition.Name=='M.Asset'

            var query = Query.CreateQuery(entities =>
                from e in entities
                where e.DefinitionName == PRODUCT_TEMPLATE
                orderby e.CreatedOn ascending
                select e);

            return webMClient.Querying.QueryAsync(query).Result.Items.ToList();
        }
    }
}


/*
    Core
        ProductName - String
        ProductLabel - String
        ProductNumber - String
        ShortDescription - String
        LongDescription - String
        ProductFamilyToProduct - M.Pim.Product is child of M.PIM.ProductFamily

    Commercial
        Available - Boolean
        StartDate - DateTime
        EndDate - DateTime
        gtin8 - String
        gtin12 - String
        GeographyToProduct - M.Pim.Product is child of M.Geography

    Packaging
        VolumeLabel - String
        PackagingLabel - String
        PackagingType - OptionList

    Assets

        ProductToMasterAsset - M.PIM.Product is parent of M.Asset
        ProductToAsset - M.PIM.Product is parent of M.Asset

    Content

        ProductToContent - M.PIM.Product is Parent of M.Content

    SAP

        BaseUnitofMeasureDescription - String
        BaseUnitOfMeasure - String
        SAPBrand - String
        CountryOfOrigin - String
        CountryIsoCode - String
        EANCodeBottle - String
        EANCodeCarton - String
        EANCodeCase - String
        EANCodeKeg - String
        GUID - String
        SPID - String
        L1ClassificationDescription
        L1Classification
        L1Code
        L2Code
        L2GroupType
        L3Brand
        L4BrandVariant
        L4Code
        L5Code
        L5IndividualVariant
        L6Code
        L6Volumne
        L7Code
        L7Configuration





 */
